package com.ga.imperialid;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private final int bg = Color.rgb(8, 9, 13);
    private final int panel = Color.rgb(19, 20, 28);
    private final int red = Color.rgb(255, 38, 63);
    private final int white = Color.rgb(245, 245, 249);
    private final int muted = Color.rgb(160, 163, 176);
    private LinearLayout content;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        showHome();
    }

    private GradientDrawable shape(int color, int radius, int strokeColor) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(radius);
        if (strokeColor != 0) d.setStroke(2, strokeColor);
        return d;
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value); t.setTextSize(size); t.setTextColor(color);
        t.setGravity(Gravity.CENTER_VERTICAL);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private void base(String eyebrow, String title, String subtitle) {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(bg);
        root.setPadding(22, 20, 22, 22);
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true);
        content = new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(content); root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        TextView brand = text("GA  /  STATUS IMPERIAL", 12, red, true);
        content.addView(brand, gap(0, 0, 0, 10));
        content.addView(text(eyebrow.toUpperCase(), 10, muted, true), gap(0,0,0,5));
        content.addView(text(title, 29, white, true), gap(0,0,0,4));
        content.addView(text(subtitle, 14, muted, false), gap(0,0,0,20));
        LinearLayout nav = new LinearLayout(this); nav.setGravity(Gravity.CENTER);
        nav.setBackground(shape(panel, 22, 0)); nav.setPadding(6, 7, 6, 7);
        String[] names = {"⌂  Início", "◉  Perfil", "♫  Música"};
        final int[] pages = {0,1,2};
        for (int i=0;i<names.length;i++) {
            final int page = pages[i]; TextView b = text(names[i], 12, white, true);
            b.setGravity(Gravity.CENTER); b.setPadding(5, 12, 5, 12);
            nav.addView(b, new LinearLayout.LayoutParams(0, -2, 1));
            b.setOnClickListener(v -> { if(page==0) showHome(); else if(page==1) showProfile(); else showMusic(); });
        }
        root.addView(nav, new LinearLayout.LayoutParams(-1, -2));
        setContentView(root);
    }

    private LinearLayout.LayoutParams gap(int l,int t,int r,int b) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2); p.setMargins(l,t,r,b); return p;
    }

    private void card(String title, String desc, String action, Runnable click) {
        LinearLayout box = new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(17, 16, 17, 16); box.setBackground(shape(panel, 20, Color.rgb(42,43,54)));
        box.addView(text(title, 17, white, true), gap(0,0,0,7));
        box.addView(text(desc, 13, muted, false), gap(0,0,0,13));
        TextView button = text(action + "   ›", 13, red, true);
        box.addView(button); box.setOnClickListener(v -> click.run()); button.setOnClickListener(v -> click.run());
        content.addView(box, gap(0,0,0,12));
    }

    private void showHome() {
        base("Painel pessoal", "O seu próprio caminho.", "Seu espaço. Sua identidade. Seu próximo nível.");
        LinearLayout hero = new LinearLayout(this); hero.setOrientation(LinearLayout.VERTICAL); hero.setPadding(19,20,19,20);
        hero.setBackground(shape(Color.rgb(35,10,18), 22, red));
        hero.addView(text("IMPERADOR • GA", 11, red, true), gap(0,0,0,8));
        hero.addView(text("STATUS: ONLINE NO MODO OFFLINE", 16, white, true), gap(0,0,0,7));
        hero.addView(text("Foco no progresso. Um passo de cada vez.", 13, muted, false));
        content.addView(hero, gap(0,0,0,18));
        content.addView(text("CENTRAL DE CONTROLE", 11, muted, true), gap(0,0,0,10));
        card("◉  Meu perfil", "Sua identidade GA e seus objetivos pessoais.", "ABRIR PERFIL", this::showProfile);
        card("♫  Central musical", "Acesso rápido ao universo musical GA / G-Flow Music.", "ABRIR MÚSICA", this::showMusic);
        card("▣  Modo offline", "O painel funciona sem internet. Nenhuma conta ou conexão é necessária.", "VER STATUS", () -> Toast.makeText(this, "Modo offline disponível: painel e perfil locais.", Toast.LENGTH_LONG).show());
        content.addView(text("GA — STATUS IMPERIAL  •  V1.0", 10, muted, false), gap(0,12,0,12));
    }

    private void showProfile() {
        base("Identidade", "Perfil GA", "Um painel pessoal guardado no próprio aparelho.");
        card("NOME DE PERFIL", "GA", "VOLTAR AO PAINEL", this::showHome);
        card("IDENTIDADE", "Criador musical independente • G-Flow Music", "ENTENDI", () -> Toast.makeText(this, "Identidade do perfil exibida.", Toast.LENGTH_SHORT).show());
        card("OBJETIVO ATUAL", "Evoluir, criar música e construir meu próprio caminho.", "VOLTAR", this::showHome);
        content.addView(text("Privacidade: esta versão não envia os dados do perfil para servidores.", 12, muted, false), gap(2,4,2,12));
    }

    private void showMusic() {
        base("Estúdio pessoal", "Central musical", "Seu atalho para criar, ouvir e organizar suas ideias.");
        card("GA • Minhas músicas", "Área reservada para suas faixas e projetos musicais.", "ABRIR YOUTUBE", () -> Toast.makeText(this, "Adicione seus links de música na próxima versão.", Toast.LENGTH_LONG).show());
        card("G-Flow Music", "Identidade musical e projetos do GA.", "VER PROJETO", () -> Toast.makeText(this, "Central musical em modo local. Internet não é necessária para abrir o app.", Toast.LENGTH_LONG).show());
        card("IDEIAS DE MÚSICA", "Summer EDM • Eletrônica • Violão • Voz masculina melódica", "VOLTAR AO PAINEL", this::showHome);
        content.addView(text("Nota: links e reprodução de faixas ainda não estão configurados nesta versão inicial.", 12, muted, false), gap(2,3,2,12));
    }
}
